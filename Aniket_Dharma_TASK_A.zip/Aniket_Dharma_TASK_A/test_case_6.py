""" TEST CASE 4 :- Testing the response of need help button
"""

import time
from selenium import webdriver

#Open Web driver
driver=webdriver.Chrome(executable_path=r"C:\chromedriver_win32\chromedriver.exe")

#Go to the hudl.com
driver.get('https://www.hudl.com/')
time.sleep(5)

#Add xpath to the variable and wait for 5 seconds after clicking on Log In
login=driver.find_element_by_xpath("/html/body/div[2]/header/div[2]/ul/li[3]/a")
login.click()
time.sleep(5)

#Add xpaath to the variable and wait for 5 seconds to open the need helppage
need_help=driver.find_element_by_xpath("/html/body/div[2]/form[1]/div[5]/a")
time.sleep(5)
need_help.click()

#Wait for 60 seconds and close the browser
time.sleep(60)
driver.quit()