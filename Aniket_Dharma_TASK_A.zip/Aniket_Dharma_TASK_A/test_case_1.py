"NAME :- ANIKET DHARMA"
"Emp ID :- 1246"

""" 
TASK A :- Automate any cases that you would think are good to test the functionality 
          of validating logging into hudl.com with your credentials.

Language: Python
FrameWork: Selenium
WebBrowser: Google Chrome
IDE : Jupyter Notebook

Execution Steps :- 1)Download the selenium webdriver suitable for your browser.
		   2)Copy the path of extracted webdrive and provide it into the code.
		   3)Open the anaconda cmd 
		   4)Run the file e.g. python file_name.PY by providing proper path.
"""

"""
TEST CASE 1 :- Accessing the login page of hudl.com and checking whether we are able to
               login by providing the valid creditionals.
"""
import time
from selenium import webdriver
#Open Web driver and provide the proper path of the selenium webdriver
driver=webdriver.Chrome(executable_path=r"C:\chromedriver_win32\chromedriver.exe")

#Go to the hudl.com
driver.get('https://www.hudl.com/')
time.sleep(5)

#Add xpath to the variable and wait for 5 sec to click on log in button
Log_in=driver.find_element_by_xpath("/html/body/div[2]/header/div[2]/ul/li[3]/a")
time.sleep(5)
Log_in.click()

#Add the xpath to the variable and wait for 5 seconds after including the email id
email = driver.find_element_by_xpath("/html/body/div[2]/form[1]/div[2]/div[1]/input")
email.send_keys("aniket.dharma@gmail.com")
time.sleep(5)

#Add the xpath to the variable and wait for 5 seconds after entering password
password = driver.find_element_by_xpath("/html/body/div[2]/form[1]/div[2]/div[2]/input")
password.send_keys("intelcore21")
time.sleep(5)

#Add the xpath to the variable and wait for 5 seconds after clicking on remember me
remember_me = driver.find_element_by_xpath("/html/body/div[2]/form[1]/div[5]/div/label")
remember_me.click()
time.sleep(5)

#Add the xpath to the variable and wait for 5 seconds after clicking on log in
login = driver.find_element_by_xpath("/html/body/div[2]/form[1]/div[4]/div/button")
login.click()
time.sleep(20)

#Wait for 60 seconds and close the browser
time.sleep(60)
driver.quit()