""" TEST CASE 2 :- Testing the response of server by providing the invalid log in
		   creditionals.
"""


import time
from selenium import webdriver

#Open Web driver
driver=webdriver.Chrome(executable_path=r"C:\chromedriver_win32\chromedriver.exe")

#Go to the hudl.com
driver.get('https://www.hudl.com/')
time.sleep(5)

# Add xpath to the variable and wait for 5 seconds 
Log_in=driver.find_element_by_xpath("/html/body/div[2]/header/div[2]/ul/li[3]/a")
time.sleep(5)
Log_in.click()

#Add the xpath to the variable and wait for 5 seconds after including the email id
email = driver.find_element_by_xpath("/html/body/div[2]/form[1]/div[2]/div[1]/input")
email.send_keys("aniket.dharmagmail.com")
time.sleep(5)

#Add the xpath to the variable and wait for 5 seconds after entering password
password = driver.find_element_by_xpath("/html/body/div[2]/form[1]/div[2]/div[2]/input")
password.send_keys("intelcore2")
time.sleep(5)

#Add the xpath to the variable and wait for 5 seconds after clicking on log in
login = driver.find_element_by_xpath("/html/body/div[2]/form[1]/div[4]/div/button")
login.click()
time.sleep(20)

#Wait for 60 seconds and close the browser
time.sleep(60)
driver.quit()